// src/scripts/pages/about/about-presenter.js
class AboutPresenter {
    constructor({ view }) {
        this._view = view;
    }
}

export default AboutPresenter; 